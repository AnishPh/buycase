Responsive Green Theme
====================
Responsive Green is a professional responsive theme.
The theme is not dependent on any core theme. Its very light weight for fast loading with modern look.

 - Professional responsive theme.
 - Simple and clean design.
 - Fixed Width.
 - Drupal standards compliant.
 - Special Toggle menu for Mobile and Table.
 - Multi-level drop-down menus.
 - Implementation of a Responsive Slideshow.
 - Use of Google Web Fonts.
 - Custom Front page region.
 - Social links.

For Drop-Down-Menu:
=====================
To Enable drop-down menu, Select "Show as expanded " at setting page of menu items.

Drupal compatibility:
=====================
This theme is compatible with Drupal 7.x.x

Design & Developed by
============
http://www.about.me/ankithinglajia
